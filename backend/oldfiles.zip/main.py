import asyncio
import os
from gemini_live_client import generate_dsl as gemini_live_response
from sentiment_analyzer import get_dsl_from_text
from dsl_executor import execute_dsl

async def process_user_input(user_text):
    """Полный pipeline: User → Gemini Live → Sentiment → DSL → SVG"""
    
    print(f"\n1️⃣ User: {user_text}")
    
    # Gemini Live отвечает
    print("2️⃣ Gemini Live responding...")
    gemini_response = await gemini_live_response(user_text)
    print(f"   Response: {gemini_response}")
    
    # Heuristic sentiment analysis
    print("3️⃣ Analyzing sentiment...")
    emotion, dsl_commands = get_dsl_from_text(gemini_response)
    print(f"   Emotion: {emotion}")
    
    # Вызови C++ для генерации SVG
    print("4️⃣ Generating SVG...")
    svg_path = execute_dsl(dsl_commands)
    
    print(f"5️⃣ Result:")
    print(f"   SVG: {svg_path}")
    
    return {
        "user": user_text,
        "response": gemini_response,
        "emotion": emotion,
        "dsl": dsl_commands,
        "svg": svg_path
    }

if __name__ == "__main__":
    result = asyncio.run(process_user_input("Привет! Мне весело!"))
    print(f"\n✅ Pipeline complete")
