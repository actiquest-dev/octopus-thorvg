import asyncio
import os
from google import genai
from google.genai import types

SYSTEM_PROMPT = """Ты - дружелюбный оптимист осьминог.
ВСЕГДА отвечай в этом ТОЧНОМ формате:
[SPEECH]текст ответа[/SPEECH]
[DSL]
EMOTION happy 1.0
WIGGLE_ARMS medium 2.0
[/DSL]"""

async def generate_dsl(user_text):
    """Генерирует DSL через Gemini Live"""
    
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = os.path.expanduser("~/octopus-thorvg/credentials.json")
    
    PROJECT_ID = "gen-lang-client-0711067295"
    LOCATION = "us-central1"
    
    client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
    
    async with client.aio.live.connect(
        model="gemini-live-2.5-flash-native-audio",
        config=types.LiveConnectConfig(
            response_modalities=["audio"],
            output_audio_transcription={},
            system_instruction=SYSTEM_PROMPT,
        ),
    ) as session:
        await session.send_client_content(
            turns=[types.Content(role="user", parts=[types.Part(text=user_text)])]
        )
        
        response_text = ""
        async for message in session.receive():
            if message.server_content:
                if message.server_content.output_transcription and message.server_content.output_transcription.text:
                    response_text += message.server_content.output_transcription.text
            
            if message.server_content and message.server_content.turn_complete:
                break
        
        return response_text

if __name__ == "__main__":
    result = asyncio.run(generate_dsl("Привет! Как дела?"))
    print("Response:")
    print(result)
