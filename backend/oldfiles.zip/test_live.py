import asyncio
import os
from google import genai
from google.genai import types

async def test():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = os.path.expanduser("~/octopus-thorvg/credentials.json")
    
    client = genai.Client(vertexai=True, project="gen-lang-client-0711067295", location="us-central1")
    
    async with client.aio.live.connect(
        model="gemini-live-2.5-flash-native-audio",
        config=types.LiveConnectConfig(
            response_modalities=["audio"],
            output_audio_transcription={},
            enable_affective_dialog=True,
        ),
    ) as session:
        await session.send_client_content(
            turns=[types.Content(role="user", parts=[types.Part(text="Привет!")])]
        )
        
        full_text = ""
        async for message in session.receive():
            if message.server_content:
                if message.server_content.output_transcription and message.server_content.output_transcription.text:
                    text = message.server_content.output_transcription.text
                    full_text += text
                    print(f"Got: {text}")
            
            if message.server_content and message.server_content.turn_complete:
                break
        
        print(f"\n=== Full Text ===\n{full_text}")

asyncio.run(test())
