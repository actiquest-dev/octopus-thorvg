import asyncio
import os
from google import genai
from google.genai import types

SYSTEM_PROMPT = """Ты осьминог. Ответь в формате:
[SPEECH]текст[/SPEECH]
[DSL]EMOTION happy 1.0[/DSL]"""

async def debug():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = os.path.expanduser("~/octopus-thorvg/credentials.json")
    
    client = genai.Client(vertexai=True, project="gen-lang-client-0711067295", location="us-central1")
    
    async with client.aio.live.connect(
        model="gemini-live-2.5-flash-native-audio",
        config=types.LiveConnectConfig(
            response_modalities=["audio"],
            output_audio_transcription={},
            enable_affective_dialog=True,
            system_instruction=SYSTEM_PROMPT,
        ),
    ) as session:
        await session.send_client_content(
            turns=[types.Content(role="user", parts=[types.Part(text="Привет!")])]
        )
        
        count = 0
        async for message in session.receive():
            count += 1
            print(f"\n=== Message {count} ===")
            print(f"Message type: {type(message).__name__}")
            
            if hasattr(message, 'server_content') and message.server_content:
                print(f"server_content exists: True")
                print(f"  - model_turn: {message.server_content.model_turn}")
                print(f"  - output_transcription: {message.server_content.output_transcription}")
                print(f"  - turn_complete: {message.server_content.turn_complete}")
                if message.server_content.output_transcription:
                    print(f"    text: {message.server_content.output_transcription.text}")
            
            if message.server_content and message.server_content.turn_complete:
                break

asyncio.run(debug())
