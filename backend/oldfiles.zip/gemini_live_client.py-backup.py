import asyncio
import os
from google import genai
from google.genai import types

SYSTEM_PROMPT = """Ты - веселый, дружелюбный осьминог. Отвечай естественно и коротко (1-2 предложения)."""

async def generate_dsl(user_text):
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = os.path.expanduser("~/octopus-thorvg/credentials.json")
    
    PROJECT_ID = "gen-lang-client-0711067295"
    LOCATION = "us-central1"
    
    client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
    
    async with client.aio.live.connect(
        model="gemini-live-2.5-flash-native-audio",
        config=types.LiveConnectConfig(
            response_modalities=["audio"],
            output_audio_transcription={},
            enable_affective_dialog=True,
            system_instruction=SYSTEM_PROMPT,
        ),
    ) as session:
        await session.send_client_content(
            turns=[types.Content(role="user", parts=[types.Part(text=user_text)])]
        )
        
        response_text = ""
        audio_data = b""
        
        async for message in session.receive():
            if message.server_content:
                if message.server_content.output_transcription and message.server_content.output_transcription.text:
                    text = message.server_content.output_transcription.text
                    response_text += text
                
                if message.server_content.model_turn:
                    for part in message.server_content.model_turn.parts:
                        if part.inline_data:
                            audio_data += part.inline_data.data
            
            if message.server_content and message.server_content.turn_complete:
                break
        
        return response_text, audio_data
