import asyncio
import websockets
import json
import os
from gemini_live_client import generate_dsl as gemini_live_response
from sentiment_analyzer import get_dsl_from_text
from dsl_executor import execute_dsl

async def handle_client(websocket, path):
    """Обработчик WebSocket клиента"""
    
    print(f"✓ Client connected: {websocket.remote_address}")
    
    try:
        async for message in websocket:
            data = json.loads(message)
            user_text = data.get("text", "")
            
            print(f"\n📨 Received: {user_text}")
            
            # Запусти pipeline
            print("⏳ Processing...")
            
            # Gemini Live
            gemini_response = await gemini_live_response(user_text)
            
            # Sentiment
            emotion, dsl_commands = get_dsl_from_text(gemini_response)
            
            # SVG
            svg_path = execute_dsl(dsl_commands)
            
            # Прочитай SVG
            with open(svg_path, 'r') as f:
                svg_content = f.read()
            
            # Отправь ответ
            response = {
                "user_text": user_text,
                "response": gemini_response,
                "emotion": emotion,
                "svg": svg_content,
                "dsl": dsl_commands
            }
            
            await websocket.send(json.dumps(response))
            print(f"✓ Sent response")
    
    except websockets.exceptions.ConnectionClosed:
        print(f"✗ Client disconnected")
    except Exception as e:
        print(f"✗ Error: {e}")

async def main():
    print("🚀 WebSocket server starting...")
    print("   ws://localhost:8765")
    
    async with websockets.serve(handle_client, "localhost", 8765):
        await asyncio.Future()  # run forever

if __name__ == "__main__":
    asyncio.run(main())
